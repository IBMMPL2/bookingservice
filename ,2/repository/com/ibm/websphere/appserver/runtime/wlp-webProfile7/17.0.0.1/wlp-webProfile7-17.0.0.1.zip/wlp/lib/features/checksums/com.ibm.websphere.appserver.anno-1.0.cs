#Mon Feb 27 04:08:30 GMT 2017
lib/features/com.ibm.websphere.appserver.anno-1.0.mf=fe454d28f39824cf8333b4c9a2db3444
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.anno_1.0-javadoc.zip=d19b15fe659ec363e2f7fa3dc8794677
lib/com.ibm.ws.anno_1.0.16.jar=a5446f3803d79a17af341b446bad2316
dev/spi/ibm/com.ibm.websphere.appserver.spi.anno_1.0.16.jar=470dd024b24ba6eecb2af21198ecdcb6
