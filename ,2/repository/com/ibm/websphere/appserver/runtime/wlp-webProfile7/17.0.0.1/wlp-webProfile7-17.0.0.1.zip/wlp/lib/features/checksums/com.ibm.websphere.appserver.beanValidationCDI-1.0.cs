#Mon Feb 27 04:08:30 GMT 2017
lib/features/com.ibm.websphere.appserver.beanValidationCDI-1.0.mf=6c9f7737a1e1e018f01248abf3044928
lib/com.ibm.ws.beanvalidation.v11.cdi_1.0.16.jar=c3eb4487cf1db0dccbaa0873e928224c
