#Mon Feb 27 04:08:31 GMT 2017
lib/com.ibm.ws.cdi.1.2.security_1.0.16.jar=f0d8ae674297c8338c0ed51c72772b76
lib/features/com.ibm.websphere.appserver.cdi1.2-appSecurity1.0.mf=1cc9823887123b802e9c5f0621144b80
