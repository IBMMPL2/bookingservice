#Mon Feb 27 04:08:29 GMT 2017
lib/com.ibm.ws.cdi.1.2.ejb_1.0.16.jar=170c3e1d4b3fcb9eb8738a67774616a0
lib/features/com.ibm.websphere.appserver.cdi1.2-ejb3.2.mf=4fae3abee97f4e544d21629ec7081f09
