#Mon Feb 27 04:08:31 GMT 2017
lib/com.ibm.ws.cdi.1.2.jndi.1.0.0_1.0.16.jar=92dfcc5a7cca30141ee29aef92f9bc06
lib/features/com.ibm.websphere.appserver.cdi1.2-jndi1.0.mf=581a7e08d9ede0dadf1a20f7a73986b5
