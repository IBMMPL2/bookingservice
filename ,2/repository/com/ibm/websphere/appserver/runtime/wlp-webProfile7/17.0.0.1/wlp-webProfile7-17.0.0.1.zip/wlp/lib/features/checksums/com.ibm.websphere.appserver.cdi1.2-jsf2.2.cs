#Mon Feb 27 04:08:29 GMT 2017
lib/com.ibm.ws.cdi.1.2.jsf_1.0.16.jar=7b0212f9edefcf5cea3f56e0aa7f65f8
lib/features/com.ibm.websphere.appserver.cdi1.2-jsf2.2.mf=d9610615184f2ff79f4242d40dd978e3
