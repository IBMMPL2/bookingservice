#Mon Feb 27 04:08:31 GMT 2017
lib/com.ibm.ws.cdi.1.2.web_1.0.16.jar=564a232c7ef95284a896dd1dd68473e7
lib/features/com.ibm.websphere.appserver.cdi1.2-servlet3.1.mf=cd6c3ec9bb5ccb4c8681fc764e05ec91
dev/api/spec/com.ibm.websphere.javaee.jsp.2.3_1.0.16.jar=f7c09f7a4d7f52652204299650487fbc
