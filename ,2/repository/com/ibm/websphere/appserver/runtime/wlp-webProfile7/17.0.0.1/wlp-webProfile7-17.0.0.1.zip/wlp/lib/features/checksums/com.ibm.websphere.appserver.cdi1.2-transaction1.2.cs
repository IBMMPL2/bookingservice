#Mon Feb 27 04:08:29 GMT 2017
lib/com.ibm.ws.cdi.1.2.transaction_1.0.16.jar=8024b8cdd7673ba3a960e425d9bed31d
lib/features/com.ibm.websphere.appserver.cdi1.2-transaction1.2.mf=57a51cfc7914d29ac331a303658fe3b5
