#Mon Feb 27 04:08:30 GMT 2017
lib/com.ibm.ws.classloader.context_1.0.16.jar=e9da42a612057b41eb371649931cd407
lib/features/com.ibm.websphere.appserver.classloaderContext-1.0.mf=bb4d4f43def75849021f88412f626518
