#Mon Feb 27 04:08:29 GMT 2017
lib/com.ibm.ws.jca.cm_1.0.16.jar=a0da28394a51a9f9d2970e08d44887dd
lib/features/com.ibm.websphere.appserver.connectionManagement-1.0.mf=a6ab35f9af286672c5dc974cdb585725
lib/com.ibm.ws.tx.zos_1.0.16.jar=f4c5d9a6655a265dff58f3d00e9d9171
