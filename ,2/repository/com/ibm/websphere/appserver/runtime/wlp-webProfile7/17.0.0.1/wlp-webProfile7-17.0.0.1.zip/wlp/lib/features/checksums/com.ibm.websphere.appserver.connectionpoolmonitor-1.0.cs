#Mon Feb 27 04:08:30 GMT 2017
dev/api/ibm/com.ibm.websphere.appserver.api.connectionpool_1.0.16.jar=87a5b4a725450483f216709f49ac31d9
lib/features/com.ibm.websphere.appserver.connectionpoolmonitor-1.0.mf=66f857de08c6808fe88688c18739173a
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.connectionpool_1.0-javadoc.zip=4858b1c1443519a1518e3b408f93a9b3
lib/com.ibm.ws.connectionpool.monitor_1.0.16.jar=ee228db3e850a60439e35663fbd73501
