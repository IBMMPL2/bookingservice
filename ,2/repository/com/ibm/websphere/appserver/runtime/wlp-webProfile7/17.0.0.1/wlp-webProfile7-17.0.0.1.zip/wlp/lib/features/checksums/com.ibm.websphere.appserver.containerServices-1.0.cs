#Mon Feb 27 04:08:31 GMT 2017
dev/spi/ibm/com.ibm.websphere.appserver.spi.containerServices_2.0.16.jar=4bc67c5dd36cd10cd184042db5a06c95
lib/features/com.ibm.websphere.appserver.containerServices-1.0.mf=d8cc7171205158ab06865aa2846fed97
lib/com.ibm.ws.resource_1.0.16.jar=7b821ddf3415014294f809c09a4f973f
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.containerServices_2.0-javadoc.zip=9108c2bfcce3e32a2940ad04b1413756
lib/com.ibm.ws.javaee.version_1.0.16.jar=ffd1fd271a7dd3a9b9948fff7b7f6dd0
lib/com.ibm.ws.serialization_1.0.16.jar=e00e98ce1763ee78dd20b810a3622181
lib/com.ibm.ws.container.service_1.0.16.jar=ee34187c62f64c5c48a44453244f320d
