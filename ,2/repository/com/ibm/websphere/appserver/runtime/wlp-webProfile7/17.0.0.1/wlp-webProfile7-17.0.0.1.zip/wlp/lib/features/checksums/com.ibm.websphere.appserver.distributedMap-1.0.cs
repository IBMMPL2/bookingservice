#Mon Feb 27 04:08:30 GMT 2017
dev/api/ibm/com.ibm.websphere.appserver.api.distributedMap_2.0.16.jar=0de3d57c054bfb7a6d9aae239fe171c2
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.distributedMap_2.0-javadoc.zip=2b2b32d31219c003272642f27c4f6643
lib/features/com.ibm.websphere.appserver.distributedMap-1.0.mf=0078441835ed19c2724dd6ef1448defb
lib/com.ibm.ws.dynacache_1.0.16.jar=b68a84db8bb668db87352ddf197ac651
