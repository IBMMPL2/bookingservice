#Mon Feb 27 04:08:30 GMT 2017
lib/features/com.ibm.websphere.appserver.dynamicBundle-1.0.mf=0923341fdfbc4f0bd4da2b3002a3dfb5
lib/com.ibm.ws.dynamic.bundle_1.0.16.jar=9fe1049f7e10595c8194335649c7b2d0
