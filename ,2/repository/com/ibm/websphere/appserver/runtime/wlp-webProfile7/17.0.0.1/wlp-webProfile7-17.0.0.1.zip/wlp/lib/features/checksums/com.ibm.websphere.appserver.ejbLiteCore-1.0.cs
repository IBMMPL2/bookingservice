#Mon Feb 27 04:08:29 GMT 2017
lib/features/com.ibm.websphere.appserver.ejbLiteCore-1.0.mf=f88fac1f331da001fe0941729dabb0b0
lib/com.ibm.ws.ejbcontainer.session_1.0.16.jar=50c57d05577ad7c17e0dc97cd77a1fef
