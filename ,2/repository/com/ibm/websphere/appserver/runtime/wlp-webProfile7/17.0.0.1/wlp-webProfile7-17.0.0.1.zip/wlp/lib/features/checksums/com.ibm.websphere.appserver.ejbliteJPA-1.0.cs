#Mon Feb 27 04:08:30 GMT 2017
lib/features/com.ibm.websphere.appserver.ejbliteJPA-1.0.mf=980e3f65a41b4be19705969533c421b8
lib/com.ibm.ws.ejbcontainer.jpa_1.0.16.jar=93bc849be680fe6b5366fa06254cd849
