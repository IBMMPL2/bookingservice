#Mon Feb 27 04:08:30 GMT 2017
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.httptransport_1.1-javadoc.zip=108f361989a66834970c3c396fffd16d
dev/spi/ibm/com.ibm.websphere.appserver.spi.httptransport_1.1.16.jar=f18a9ec3fdb5c73c75e23ddf6aa0610c
lib/com.ibm.ws.transport.http_1.0.16.jar=571288cd54dc6582c0b8e22af5ecc338
lib/features/com.ibm.websphere.appserver.httptransport-1.0.mf=270111e2478e743449faebede9f4e254
