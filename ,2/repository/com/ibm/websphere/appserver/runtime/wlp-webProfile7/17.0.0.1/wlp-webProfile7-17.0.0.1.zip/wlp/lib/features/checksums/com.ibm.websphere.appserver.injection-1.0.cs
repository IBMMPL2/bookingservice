#Mon Feb 27 04:08:30 GMT 2017
lib/features/com.ibm.websphere.appserver.injection-1.0.mf=44e87c9476760efa1ae14c83047aa2a5
lib/com.ibm.ws.injection_1.0.16.jar=62669dfa6f8e9186a894c6ed1c47d32a
