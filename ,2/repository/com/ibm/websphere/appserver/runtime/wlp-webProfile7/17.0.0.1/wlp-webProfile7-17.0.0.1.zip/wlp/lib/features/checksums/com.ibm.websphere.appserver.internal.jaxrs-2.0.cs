#Mon Feb 27 04:08:30 GMT 2017
lib/features/com.ibm.websphere.appserver.internal.jaxrs-2.0.mf=008c022d71fe4143d3bba7644f7aff7b
lib/com.ibm.ws.jaxrs.2.0.tools_1.0.16.jar=962da38aa622638b23acca2526c71306
lib/com.ibm.ws.jaxrs.2.0.client_1.0.16.jar=62abe42ea9f186eebc4fdec362e832a0
dev/api/spec/com.ibm.websphere.javaee.jaxrs.2.0_1.0.16.jar=0c1e72f93fabcdd92ec78ae719d5faad
lib/com.ibm.ws.jaxrs.2.0.server_1.0.16.jar=7b249cfc49300ff469b3025613a19040
lib/com.ibm.ws.jaxrs.2.0.web_1.0.16.jar=ddb7618d0430688f901d13c6a7cbbae5
lib/com.ibm.ws.org.apache.ws.xmlschema.core.2.0.3_1.0.16.jar=6774cff28f3e72da0ca2e3f674575aeb
lib/com.ibm.ws.org.apache.xml.resolver.1.2_1.0.16.jar=7fc39932f5c72dc61e8181f8fe6e39b9
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.jaxrs20_1.0-javadoc.zip=e0863122f3d4d34d9c6c9819f64f364f
dev/api/ibm/com.ibm.websphere.appserver.api.jaxrs20_1.0.16.jar=f89b1b098b6dff883675dceb55a92aa4
lib/com.ibm.ws.org.apache.neethi.3.0.2_1.0.16.jar=e258ae9980b2c5279edb808811f4f81e
lib/com.ibm.ws.jaxrs.2.0.common_1.0.16.jar=76a01d4b52a9558c32cd3d9900c40643
bin/jaxrs/tools/wadl2java.jar=fc76905bffc8948fea4107fe9a38cf80
