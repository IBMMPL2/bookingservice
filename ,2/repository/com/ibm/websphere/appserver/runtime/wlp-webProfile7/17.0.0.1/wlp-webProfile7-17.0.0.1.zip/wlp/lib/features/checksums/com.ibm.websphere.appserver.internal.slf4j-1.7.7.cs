#Mon Feb 27 04:08:31 GMT 2017
lib/features/com.ibm.websphere.appserver.internal.slf4j-1.7.7.mf=c40e6d79951816795a8d524b3c9efa6a
lib/com.ibm.ws.org.slf4j.jdk14.1.7.7_1.0.16.jar=84923e9c7d2e6cfc5c257dcba8cf60ed
lib/com.ibm.ws.org.slf4j.api.1.7.7_1.0.16.jar=174d457306964feeb7daaaa1266485d7
