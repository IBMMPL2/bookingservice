#Mon Feb 27 04:08:29 GMT 2017
lib/features/com.ibm.websphere.appserver.javaeeCompatible-7.0.mf=7e3b5845261a3060ca448300074a2f6a
lib/com.ibm.ws.javaee.version_1.0.16.jar=ffd1fd271a7dd3a9b9948fff7b7f6dd0
