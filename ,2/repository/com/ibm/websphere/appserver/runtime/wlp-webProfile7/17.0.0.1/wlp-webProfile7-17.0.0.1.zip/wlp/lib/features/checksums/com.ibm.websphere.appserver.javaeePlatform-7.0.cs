#Mon Feb 27 04:08:30 GMT 2017
lib/features/com.ibm.websphere.appserver.javaeePlatform-7.0.mf=bc617bd52be955837df301b1f49ff50b
lib/com.ibm.ws.javaee.version_1.0.16.jar=ffd1fd271a7dd3a9b9948fff7b7f6dd0
lib/com.ibm.ws.javaee.platform.v7_1.0.16.jar=4e6f37ac56318547f01c207c4832f9c9
lib/com.ibm.ws.javaee.platform.defaultresource_1.0.16.jar=cda24db50cbd2ba79104765734663294
