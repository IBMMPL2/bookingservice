#Mon Feb 27 04:08:30 GMT 2017
lib/com.ibm.ws.javaee.platform.v7.jndi_1.0.16.jar=28cd365cdd5eec4fcbc30f300f82b615
lib/features/com.ibm.websphere.appserver.javaeePlatform7.0-jndi1.0.mf=ac6f312e2a912ef39be09730af30390d
