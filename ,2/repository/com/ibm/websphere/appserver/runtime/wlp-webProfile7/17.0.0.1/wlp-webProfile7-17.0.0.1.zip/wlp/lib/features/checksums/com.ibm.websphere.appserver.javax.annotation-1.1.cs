#Mon Feb 27 04:08:29 GMT 2017
lib/features/com.ibm.websphere.appserver.javax.annotation-1.1.mf=075ecc4457982fe5e58ce4c63a838213
dev/api/spec/com.ibm.websphere.javaee.annotation.1.1_1.0.16.jar=b883d4fb85b86a0fc670acf43ed084d5
