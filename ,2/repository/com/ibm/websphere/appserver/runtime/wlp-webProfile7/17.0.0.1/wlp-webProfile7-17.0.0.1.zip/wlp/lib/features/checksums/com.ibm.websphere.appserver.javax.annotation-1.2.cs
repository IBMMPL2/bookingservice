#Mon Feb 27 04:08:30 GMT 2017
dev/api/spec/com.ibm.websphere.javaee.annotation.1.2_1.0.16.jar=995dec4dd8da457ae30379822000b87e
lib/features/com.ibm.websphere.appserver.javax.annotation-1.2.mf=11a1637d2e510a2be8e86231afe51795
