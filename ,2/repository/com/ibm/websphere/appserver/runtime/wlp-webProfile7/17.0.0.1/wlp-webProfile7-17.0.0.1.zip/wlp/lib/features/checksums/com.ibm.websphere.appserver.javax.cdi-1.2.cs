#Mon Feb 27 04:08:30 GMT 2017
dev/api/spec/com.ibm.websphere.javaee.cdi.1.2_1.2.16.jar=0a56b28246d0527ee55c89d051c1838a
lib/features/com.ibm.websphere.appserver.javax.cdi-1.2.mf=d37fa20bf0d46fb98282387856ae6e53
