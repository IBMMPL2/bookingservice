#Mon Feb 27 04:08:30 GMT 2017
lib/features/com.ibm.websphere.appserver.javax.connector.internal-1.6.mf=19021794a3f653d73da5aa3ab4ae2f59
dev/api/spec/com.ibm.websphere.javaee.connector.1.6_1.0.16.jar=c1019e7e3d6fd69de84faad7a98ab274
