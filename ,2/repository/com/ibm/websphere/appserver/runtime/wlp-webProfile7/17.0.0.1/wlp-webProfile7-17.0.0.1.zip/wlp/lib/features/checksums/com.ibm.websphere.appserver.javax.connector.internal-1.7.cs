#Mon Feb 27 04:08:29 GMT 2017
dev/api/spec/com.ibm.websphere.javaee.connector.1.7_1.0.16.jar=f812a51e6036e5f5e30eb1fcc9cd70a8
lib/features/com.ibm.websphere.appserver.javax.connector.internal-1.7.mf=4a57e29f1d3aa68db222177f4cec6317
