#Mon Feb 27 04:08:29 GMT 2017
dev/api/spec/com.ibm.websphere.javaee.ejb.3.2_1.0.16.jar=87062b29acf7a0ab9c1991290431d149
lib/features/com.ibm.websphere.appserver.javax.ejb-3.2.mf=719d3028d6db9e1cd8706b3e19d1e352
