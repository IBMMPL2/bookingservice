#Mon Feb 27 04:08:29 GMT 2017
dev/api/spec/com.ibm.websphere.javaee.interceptor.1.2_1.0.16.jar=8f6875149ae6917b40d799e6050474ca
lib/features/com.ibm.websphere.appserver.javax.interceptor-1.2.mf=76059fa677cd76685a3af5f2a31a2f49
