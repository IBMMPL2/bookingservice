#Mon Feb 27 04:08:29 GMT 2017
lib/features/com.ibm.websphere.appserver.javax.mail-1.5.mf=b455a0a8215ed700ec967a1d2b0876c2
lib/com.ibm.ws.com.sun.mail.javax.mail.1.5_1.5.16.jar=6d53dbf4b534bede3e0a1b55b543ec42
