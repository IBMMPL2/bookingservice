#Mon Feb 27 04:08:30 GMT 2017
dev/api/spec/com.ibm.websphere.javaee.persistence.2.1_1.0.16.jar=ecf60441dc1f1e8d183efb2f4402f2ab
lib/com.ibm.ws.javaee.persistence.api.2.1_1.0.16.jar=64c87f8610f4e89123bdc622953a1184
lib/features/com.ibm.websphere.appserver.javax.persistence-2.1.mf=3b4793f72ea0d4a66b4eb80caf0ecf24
