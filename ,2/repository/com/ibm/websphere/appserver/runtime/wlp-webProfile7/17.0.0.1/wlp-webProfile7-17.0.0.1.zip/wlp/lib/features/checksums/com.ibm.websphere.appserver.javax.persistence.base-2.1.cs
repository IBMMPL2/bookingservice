#Mon Feb 27 04:08:30 GMT 2017
lib/com.ibm.ws.javaee.persistence.2.1_1.0.16.jar=ccb49945d161e1aaf8adbd7ada379be5
lib/features/com.ibm.websphere.appserver.javax.persistence.base-2.1.mf=0bb1cf9bf2de28784cd0c9da8eef2049
