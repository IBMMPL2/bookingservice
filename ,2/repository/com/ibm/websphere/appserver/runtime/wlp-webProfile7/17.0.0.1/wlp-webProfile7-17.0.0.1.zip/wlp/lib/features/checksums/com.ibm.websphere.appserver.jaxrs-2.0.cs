#Mon Feb 27 04:08:31 GMT 2017
lib/features/com.ibm.websphere.appserver.jaxrs-2.0.mf=0a1d937fed90a99815c26d554610ce1e
