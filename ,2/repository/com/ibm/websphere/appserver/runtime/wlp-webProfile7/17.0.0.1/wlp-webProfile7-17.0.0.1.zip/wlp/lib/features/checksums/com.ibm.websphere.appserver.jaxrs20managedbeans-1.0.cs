#Mon Feb 27 04:08:30 GMT 2017
lib/com.ibm.ws.jaxrs.2.0.managedbeans_1.0.16.jar=d5e0c9383374e02ecea6ee0992e1369a
lib/features/com.ibm.websphere.appserver.jaxrs20managedbeans-1.0.mf=bf9564fe6b6cc1b6f0af11a226ec25b3
