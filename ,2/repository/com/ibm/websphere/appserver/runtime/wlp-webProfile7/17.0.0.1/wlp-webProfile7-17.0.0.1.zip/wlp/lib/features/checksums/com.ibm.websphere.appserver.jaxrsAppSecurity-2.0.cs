#Mon Feb 27 04:08:30 GMT 2017
lib/com.ibm.ws.jaxrs.2.0.security_1.0.16.jar=b6911a6be2b08c31c0fc793361d01e05
lib/features/com.ibm.websphere.appserver.jaxrsAppSecurity-2.0.mf=821868236a4731154ce7485de38a18c6
