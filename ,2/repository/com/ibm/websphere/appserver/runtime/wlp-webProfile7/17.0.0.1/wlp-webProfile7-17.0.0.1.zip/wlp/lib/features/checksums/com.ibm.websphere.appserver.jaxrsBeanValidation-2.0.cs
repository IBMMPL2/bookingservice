#Mon Feb 27 04:08:30 GMT 2017
lib/com.ibm.ws.jaxrs.2.0.beanvalidation_1.0.16.jar=5ac3e869bd23c42e1094e2078811e1b6
lib/features/com.ibm.websphere.appserver.jaxrsBeanValidation-2.0.mf=45c96347b5cbf60d88aa204de9e4917d
