#Mon Feb 27 04:08:30 GMT 2017
lib/features/com.ibm.websphere.appserver.jaxrsClient-2.0.mf=513dc86a0cd4de494ee967ed0b2c94bd
lib/com.ibm.ws.jaxrs.2.0.client_1.0.16.jar=62abe42ea9f186eebc4fdec362e832a0
