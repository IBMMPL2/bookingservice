#Mon Feb 27 04:08:30 GMT 2017
lib/features/com.ibm.websphere.appserver.jaxrscdi-2.0.mf=b9b3ea36d0353af49e2dc59e175d3c7f
lib/com.ibm.ws.jaxrs.2.0.cdi_1.0.16.jar=a60323586e0145616758f75ca4410cda
