#Mon Feb 27 04:08:30 GMT 2017
lib/features/com.ibm.websphere.appserver.jaxrsejb-2.0.mf=6aa2dd6da7e9c3617ac8cf038f119d50
lib/com.ibm.ws.jaxrs.2.0.ejb_1.0.16.jar=bfb00759556691ad6bf8ef3e02f740f8
