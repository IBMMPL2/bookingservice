#Mon Feb 27 04:08:30 GMT 2017
lib/com.ibm.ws.jdbc_1.0.16.jar=33e73d3f32ac33ec51841bb5260fc909
lib/com.ibm.ws.jdbc.4.1_1.0.16.jar=208d2e443d6f1cca49bf4608a506d5aa
lib/features/com.ibm.websphere.appserver.jdbc-4.1.mf=70db253cb4b785a8e13bcbe2de222d51
