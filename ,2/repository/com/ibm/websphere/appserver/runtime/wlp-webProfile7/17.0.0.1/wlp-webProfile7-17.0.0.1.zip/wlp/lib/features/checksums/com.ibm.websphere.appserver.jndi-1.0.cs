#Mon Feb 27 04:08:31 GMT 2017
lib/com.ibm.ws.org.apache.aries.jndi.api.1.1.1_1.1.16.jar=2fc13ef347bade3b6163eaa3b9b5cd09
lib/com.ibm.ws.jndi_1.0.16.jar=77bbe4db89d2fa05362ff134a6b1c948
lib/features/com.ibm.websphere.appserver.jndi-1.0.mf=8d7afdf8db8ea913df7c1dcc1c2aba87
lib/com.ibm.ws.org.apache.aries.jndi.core.1.0.3_1.1.16.jar=f023cb200873132a258a4e71e02b228b
lib/com.ibm.ws.jndi.url.contexts_1.0.16.jar=e44e546e9513ba44a151b786b0087cdb
