#Mon Feb 27 04:08:29 GMT 2017
lib/com.ibm.ws.jpa.container_1.0.16.jar=52564c005e6c1fdb8771070f8373fe90
lib/com.ibm.ws.jpa.container.v21_1.0.16.jar=e259dbe21652c5d4940a545cac8985c4
lib/com.ibm.ws.jpa.container.eclipselink_1.0.16.jar=c5553bb786fd8703b26cadf0b3592ebf
lib/features/com.ibm.websphere.appserver.jpa-2.1.mf=9dc9781665ccd19e18531a44c895cc34
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.eclipselink_1.0.16.jar=449c5e10a690845773984e2ea3d8da53
