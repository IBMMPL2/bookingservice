#Mon Feb 27 04:08:30 GMT 2017
lib/com.ibm.ws.jpa.container.beanvalidation.1.1_1.0.16.jar=3ab31f4fca0475fe2f96b783f989fd85
lib/features/com.ibm.websphere.appserver.jpa2.0-2.1-bv1.1.mf=9ff48bc099c8297d79b584a4e6205707
