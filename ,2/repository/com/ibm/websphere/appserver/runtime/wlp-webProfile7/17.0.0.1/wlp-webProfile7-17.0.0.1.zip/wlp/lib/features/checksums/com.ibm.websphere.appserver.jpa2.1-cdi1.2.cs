#Mon Feb 27 04:08:30 GMT 2017
lib/com.ibm.ws.jpa.container.v21.cdi_1.0.16.jar=137c2e7775caffc155124cdd005615a8
lib/features/com.ibm.websphere.appserver.jpa2.1-cdi1.2.mf=ef1fe3f811273acae863e993ee4f0d4d
