#Mon Feb 27 04:08:30 GMT 2017
lib/features/com.ibm.websphere.appserver.json-1.0.mf=a835d50d0343288984ca302b0f0fb49e
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.json_1.0-javadoc.zip=58cb87efbbb282c9367053f9672c1821
dev/api/ibm/com.ibm.websphere.appserver.api.json_1.0.16.jar=2041688fb1aeb8ac0fa2420ccd3e6b32
lib/com.ibm.json4j_1.0.16.jar=1abc969efc472522b99fb4fc5a7259df
