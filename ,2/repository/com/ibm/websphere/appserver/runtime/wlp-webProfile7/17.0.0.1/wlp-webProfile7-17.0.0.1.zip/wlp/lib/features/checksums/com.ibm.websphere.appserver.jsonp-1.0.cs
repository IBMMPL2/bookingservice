#Mon Feb 27 04:08:29 GMT 2017
dev/api/spec/com.ibm.websphere.javaee.jsonp.1.0_1.0.16.jar=a3d449bb9721244976ac607b6a08a70a
lib/com.ibm.ws.org.glassfish.json.1.0_1.0.16.jar=0144511af98b934a558cca22a5fb2b99
lib/features/com.ibm.websphere.appserver.jsonp-1.0.mf=32d82e7f5fafbf391494af309c0a0086
