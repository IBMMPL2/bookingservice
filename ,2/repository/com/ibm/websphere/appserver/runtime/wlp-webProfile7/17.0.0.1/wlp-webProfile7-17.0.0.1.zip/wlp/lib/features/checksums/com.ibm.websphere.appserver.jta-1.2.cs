#Mon Feb 27 04:08:30 GMT 2017
lib/features/com.ibm.websphere.appserver.jta-1.2.mf=93baef901a54c324950c888d17afa5ab
dev/api/spec/com.ibm.websphere.javaee.transaction.1.2_1.0.16.jar=3e170e264dbd1c80e55087b4cccf1a8e
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.16.jar=581d51c0e8594f7423c5230861eb2714
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=39368537599fcc2afd4a036ece45764f
