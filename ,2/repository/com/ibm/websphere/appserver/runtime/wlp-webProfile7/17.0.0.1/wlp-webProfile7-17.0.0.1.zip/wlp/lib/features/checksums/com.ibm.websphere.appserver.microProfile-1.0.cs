#Mon Feb 27 04:08:30 GMT 2017
lib/features/com.ibm.websphere.appserver.microProfile-1.0.mf=f219c2fb97bbcab84427bb4ea41b8ad9
lib/com.ibm.ws.require.java8_1.0.16.jar=3a3a102dfb13bda0dab434a68ed43103
