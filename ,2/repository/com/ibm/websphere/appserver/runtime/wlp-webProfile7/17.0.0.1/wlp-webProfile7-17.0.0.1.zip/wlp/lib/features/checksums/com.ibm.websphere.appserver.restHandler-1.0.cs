#Mon Feb 27 04:08:30 GMT 2017
dev/spi/ibm/com.ibm.websphere.appserver.spi.restHandler_1.5.16.jar=9da7c52f5d59a1917cfff64222cd7db7
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.restHandler_1.5-javadoc.zip=e57732a724099c72ce7e82a97662bbd9
lib/com.ibm.ws.org.joda.time.1.6.2_1.0.16.jar=f3f349656e2157e6a106889235f670d7
lib/features/com.ibm.websphere.appserver.restHandler-1.0.mf=9f29a5a97a5d53e3003b1caabf0bb62f
lib/com.ibm.websphere.rest.api.discovery_1.0.16.jar=16ebfbbc9482bcb4ac5fea21eb26d44d
lib/com.ibm.websphere.collective.plugins_1.0.16.jar=c6b46a7c81ae4cc5f0ce7c301a978766
lib/com.ibm.websphere.jsonsupport_1.0.16.jar=e992a1c7303ec57c883baf25eda8e2b2
lib/com.ibm.ws.rest.handler_1.0.16.jar=e19b0853497616beff2b5ac027b75a39
lib/com.ibm.websphere.rest.handler_1.0.16.jar=c4551d8402f9b4692cebfc0ce19928b7
