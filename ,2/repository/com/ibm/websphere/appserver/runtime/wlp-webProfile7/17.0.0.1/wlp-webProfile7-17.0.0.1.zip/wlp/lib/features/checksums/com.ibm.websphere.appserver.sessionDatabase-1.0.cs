#Mon Feb 27 04:08:29 GMT 2017
lib/com.ibm.ws.session_1.0.16.jar=286ea87e8c06bb639f63ded7c40bb573
lib/features/com.ibm.websphere.appserver.sessionDatabase-1.0.mf=8fb98280cc6ce1c23b3193c20e8f7225
lib/com.ibm.ws.session.db_1.0.16.jar=469a35e092d7f181211755e91d50d85f
lib/com.ibm.websphere.security_1.0.16.jar=4a334d2b041a831e9b29014bf4191f47
lib/com.ibm.ws.serialization_1.0.16.jar=e00e98ce1763ee78dd20b810a3622181
