#Mon Feb 27 04:08:30 GMT 2017
lib/com.ibm.ws.session.monitor_1.0.16.jar=5b97921e26bfadeb821070658bd63ba9
dev/api/ibm/com.ibm.websphere.appserver.api.sessionstats_1.0.16.jar=50144be52c17b380a952fad735c58be7
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.sessionstats_1.0-javadoc.zip=5f6263c91eaba0896262745500605e92
lib/features/com.ibm.websphere.appserver.sessionMonitor-1.0.mf=5b8fea360d280a5e70c5d1120c5fd3ae
