#Mon Feb 27 04:08:30 GMT 2017
lib/com.ibm.ws.tx.jta.extensions_1.0.16.jar=86a7a2cf953972f71085bdb5386ae028
lib/com.ibm.ws.recoverylog_1.0.16.jar=98c019850a60266a76f6368438656ca1
lib/com.ibm.rls.jdbc_1.0.16.jar=0df462047fc992e5d84a78f764957002
dev/spi/ibm/com.ibm.websphere.appserver.spi.transaction_1.1.16.jar=3eb3fd2e656419f9452f9496f4d93267
lib/com.ibm.ws.transaction_1.0.16.jar=9daa45212c9238accaecf97bf56258cf
lib/com.ibm.tx.jta_1.0.16.jar=d3a54e819af41c02534d56258ac1b899
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.transaction_1.1-javadoc.zip=d3187fc459bfd98d34db0b403468cf2f
lib/com.ibm.ws.tx.embeddable_1.0.16.jar=48f4dd65abd5dab7401f5621bb57058c
lib/com.ibm.tx.ltc_1.0.16.jar=84c841060c9a7356ce4d8faf5e46e33a
lib/features/com.ibm.websphere.appserver.transaction-1.2.mf=79f12dc474f76391e8d9c8c3b1209fac
lib/com.ibm.ws.transaction.cdi_1.0.16.jar=abed55b97149ec9e421dcf18aca8a2f0
lib/com.ibm.ws.cdi.1.2.interfaces_1.0.16.jar=7fdf87366b2bed73acb323889c0dfef0
lib/com.ibm.tx.util_1.0.16.jar=044d6441ed9c9ac1402cf6e7fc3b4b53
