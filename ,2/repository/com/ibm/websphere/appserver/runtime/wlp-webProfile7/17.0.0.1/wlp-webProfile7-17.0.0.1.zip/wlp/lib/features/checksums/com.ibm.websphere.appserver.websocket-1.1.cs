#Mon Feb 27 04:08:30 GMT 2017
dev/api/ibm/com.ibm.websphere.appserver.api.wsoc_1.0.16.jar=2730b7dfb6bed61cc6b871941b01f46f
lib/com.ibm.ws.wsoc_1.0.16.jar=0556bca387cb85c699aafd1b003eb966
lib/com.ibm.ws.wsoc.1.1_1.0.16.jar=f1626781ef3491f253d44412ae0dde2c
lib/features/com.ibm.websphere.appserver.websocket-1.1.mf=8ee0b898e3018575f6252f589a79a80d
dev/api/spec/com.ibm.websphere.javaee.websocket.1.1_1.0.16.jar=acf467532ce2a4ff950e16452dd10f03
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.wsoc_1.0-javadoc.zip=8f6e8d7092af585ab2e375a6d722bc29
