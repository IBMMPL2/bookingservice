#Mon Feb 27 04:08:29 GMT 2017
lib/com.ibm.ws.wsoc.cdi.weld_1.0.16.jar=9251aca868f748c530592548c4d6526d
lib/features/com.ibm.websphere.appserver.websocketCDI-1.2.mf=ffa93da2900e3583727547f1120923b9
